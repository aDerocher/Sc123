# Code Challenges

This directory should contain three files:

- contacts.csv
- contacts-requests.php
- this readme
- sorting.php

The challenges are explained in `contacts-requests.php` and `sorting.php`.

Please don't send us plagiarized code. That's a disqualifier. We use code challenges to assess how you think through a problem and craft a communicable solution. Submitting plagiarized code doesn't allow us to do that, and robs you of the opportunity to express your capabilities. Thanks in advance.
