Can probably assume:
 - Years will always be 4 digits. Since cars have been around for more than 100 years, and all example cases have 4 digits.
 - years will always be at the start or end of the name (no one would do 'Alpha 2004 Romeo')
 - last letter of string will only be a pluralizing 's' if the year is at the front (becuase you wouldn't say Ferarri 2004's or Mustang 2004's, you would list '2018 Volkswagons' or '1999 Hondas')
